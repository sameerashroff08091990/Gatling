var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "47",
        "ok": "47",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "349",
        "ok": "349",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11672",
        "ok": "11672",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3069",
        "ok": "3069",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "3629",
        "ok": "3629",
        "ko": "-"
    },
    "percentiles1": {
        "total": "884",
        "ok": "884",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4352",
        "ok": "4352",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10868",
        "ok": "10868",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11577",
        "ok": "11577",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 22,
    "percentage": 47
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 3,
    "percentage": 6
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 22,
    "percentage": 47
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "1.567",
        "ok": "1.567",
        "ko": "-"
    }
},
contents: {
"req_launch-9506f": {
        type: "REQUEST",
        name: "Launch",
path: "Launch",
pathFormatted: "req_launch-9506f",
stats: {
    "name": "Launch",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2118",
        "ok": "2118",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_favicon-ico-8af3a": {
        type: "REQUEST",
        name: "favicon.ico",
path: "favicon.ico",
pathFormatted: "req_favicon-ico-8af3a",
stats: {
    "name": "favicon.ico",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "387",
        "ok": "387",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "418",
        "ok": "418",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "31",
        "ok": "31",
        "ko": "-"
    },
    "percentiles1": {
        "total": "418",
        "ok": "418",
        "ko": "-"
    },
    "percentiles2": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles3": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "percentiles4": {
        "total": "448",
        "ok": "448",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_main-b9d87ff6-c-5b643": {
        type: "REQUEST",
        name: "main.b9d87ff6.chunk.css",
path: "main.b9d87ff6.chunk.css",
pathFormatted: "req_main-b9d87ff6-c-5b643",
stats: {
    "name": "main.b9d87ff6.chunk.css",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1195",
        "ok": "1195",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3730",
        "ok": "3730",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2463",
        "ok": "2463",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1268",
        "ok": "1268",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2463",
        "ok": "2463",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3096",
        "ok": "3096",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3603",
        "ok": "3603",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3705",
        "ok": "3705",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 50
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_2-a1a947cf-chun-47adf": {
        type: "REQUEST",
        name: "2.a1a947cf.chunk.js",
path: "2.a1a947cf.chunk.js",
pathFormatted: "req_2-a1a947cf-chun-47adf",
stats: {
    "name": "2.a1a947cf.chunk.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4223",
        "ok": "4223",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4399",
        "ok": "4399",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4311",
        "ok": "4311",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "88",
        "ok": "88",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4311",
        "ok": "4311",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4355",
        "ok": "4355",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4390",
        "ok": "4390",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4397",
        "ok": "4397",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_main-3db41035-c-e0f60": {
        type: "REQUEST",
        name: "main.3db41035.chunk.js",
path: "main.3db41035.chunk.js",
pathFormatted: "req_main-3db41035-c-e0f60",
stats: {
    "name": "main.3db41035.chunk.js",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2123",
        "ok": "2123",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2199",
        "ok": "2199",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2161",
        "ok": "2161",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2161",
        "ok": "2161",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2180",
        "ok": "2180",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2195",
        "ok": "2195",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2198",
        "ok": "2198",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_login-99dea": {
        type: "REQUEST",
        name: "Login",
path: "Login",
pathFormatted: "req_login-99dea",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "360",
        "ok": "360",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1945",
        "ok": "1945",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1153",
        "ok": "1153",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "793",
        "ok": "793",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1153",
        "ok": "1153",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1549",
        "ok": "1549",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1866",
        "ok": "1866",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1929",
        "ok": "1929",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 50
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-1-46da4": {
        type: "REQUEST",
        name: "request_1",
path: "request_1",
pathFormatted: "req_request-1-46da4",
stats: {
    "name": "request_1",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1463",
        "ok": "1463",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1485",
        "ok": "1485",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1474",
        "ok": "1474",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11",
        "ok": "11",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1474",
        "ok": "1474",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1480",
        "ok": "1480",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1484",
        "ok": "1484",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1485",
        "ok": "1485",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-3-d0973": {
        type: "REQUEST",
        name: "request_3",
path: "request_3",
pathFormatted: "req_request-3-d0973",
stats: {
    "name": "request_3",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "589",
        "ok": "589",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "827",
        "ok": "827",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "708",
        "ok": "708",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "119",
        "ok": "119",
        "ko": "-"
    },
    "percentiles1": {
        "total": "708",
        "ok": "708",
        "ko": "-"
    },
    "percentiles2": {
        "total": "768",
        "ok": "768",
        "ko": "-"
    },
    "percentiles3": {
        "total": "815",
        "ok": "815",
        "ko": "-"
    },
    "percentiles4": {
        "total": "825",
        "ok": "825",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 50
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 50
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-4-e7d1b": {
        type: "REQUEST",
        name: "request_4",
path: "request_4",
pathFormatted: "req_request-4-e7d1b",
stats: {
    "name": "request_4",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "percentiles2": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "percentiles3": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "percentiles4": {
        "total": "556",
        "ok": "556",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.033",
        "ok": "0.033",
        "ko": "-"
    }
}
    },"req_request-5-48829": {
        type: "REQUEST",
        name: "request_5",
path: "request_5",
pathFormatted: "req_request-5-48829",
stats: {
    "name": "request_5",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "360",
        "ok": "360",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "538",
        "ok": "538",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "89",
        "ok": "89",
        "ko": "-"
    },
    "percentiles1": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "percentiles2": {
        "total": "494",
        "ok": "494",
        "ko": "-"
    },
    "percentiles3": {
        "total": "529",
        "ok": "529",
        "ko": "-"
    },
    "percentiles4": {
        "total": "536",
        "ok": "536",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-6-027a9": {
        type: "REQUEST",
        name: "request_6",
path: "request_6",
pathFormatted: "req_request-6-027a9",
stats: {
    "name": "request_6",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "382",
        "ok": "382",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "416",
        "ok": "416",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "34",
        "ok": "34",
        "ko": "-"
    },
    "percentiles1": {
        "total": "416",
        "ok": "416",
        "ko": "-"
    },
    "percentiles2": {
        "total": "432",
        "ok": "432",
        "ko": "-"
    },
    "percentiles3": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "percentiles4": {
        "total": "448",
        "ok": "448",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-8-ef0c8": {
        type: "REQUEST",
        name: "request_8",
path: "request_8",
pathFormatted: "req_request-8-ef0c8",
stats: {
    "name": "request_8",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "574",
        "ok": "574",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "884",
        "ok": "884",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "729",
        "ok": "729",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "155",
        "ok": "155",
        "ko": "-"
    },
    "percentiles1": {
        "total": "729",
        "ok": "729",
        "ko": "-"
    },
    "percentiles2": {
        "total": "807",
        "ok": "807",
        "ko": "-"
    },
    "percentiles3": {
        "total": "869",
        "ok": "869",
        "ko": "-"
    },
    "percentiles4": {
        "total": "881",
        "ok": "881",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1,
    "percentage": 50
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 50
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-7-f222f": {
        type: "REQUEST",
        name: "request_7",
path: "request_7",
pathFormatted: "req_request-7-f222f",
stats: {
    "name": "request_7",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "349",
        "ok": "349",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "606",
        "ok": "606",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "percentiles1": {
        "total": "478",
        "ok": "478",
        "ko": "-"
    },
    "percentiles2": {
        "total": "542",
        "ok": "542",
        "ko": "-"
    },
    "percentiles3": {
        "total": "593",
        "ok": "593",
        "ko": "-"
    },
    "percentiles4": {
        "total": "603",
        "ok": "603",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-10-1cfbe": {
        type: "REQUEST",
        name: "request_10",
path: "request_10",
pathFormatted: "req_request-10-1cfbe",
stats: {
    "name": "request_10",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "377",
        "ok": "377",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "491",
        "ok": "491",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "57",
        "ok": "57",
        "ko": "-"
    },
    "percentiles1": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles2": {
        "total": "463",
        "ok": "463",
        "ko": "-"
    },
    "percentiles3": {
        "total": "485",
        "ok": "485",
        "ko": "-"
    },
    "percentiles4": {
        "total": "490",
        "ok": "490",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-9-d127e": {
        type: "REQUEST",
        name: "request_9",
path: "request_9",
pathFormatted: "req_request-9-d127e",
stats: {
    "name": "request_9",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "524",
        "ok": "524",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "616",
        "ok": "616",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "570",
        "ok": "570",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "46",
        "ok": "46",
        "ko": "-"
    },
    "percentiles1": {
        "total": "570",
        "ok": "570",
        "ko": "-"
    },
    "percentiles2": {
        "total": "593",
        "ok": "593",
        "ko": "-"
    },
    "percentiles3": {
        "total": "611",
        "ok": "611",
        "ko": "-"
    },
    "percentiles4": {
        "total": "615",
        "ok": "615",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-11-f11e8": {
        type: "REQUEST",
        name: "request_11",
path: "request_11",
pathFormatted: "req_request-11-f11e8",
stats: {
    "name": "request_11",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "377",
        "ok": "377",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "502",
        "ok": "502",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "percentiles1": {
        "total": "440",
        "ok": "440",
        "ko": "-"
    },
    "percentiles2": {
        "total": "471",
        "ok": "471",
        "ko": "-"
    },
    "percentiles3": {
        "total": "496",
        "ok": "496",
        "ko": "-"
    },
    "percentiles4": {
        "total": "501",
        "ok": "501",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-12-61da2": {
        type: "REQUEST",
        name: "request_12",
path: "request_12",
pathFormatted: "req_request-12-61da2",
stats: {
    "name": "request_12",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "372",
        "ok": "372",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "413",
        "ok": "413",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "393",
        "ok": "393",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "percentiles1": {
        "total": "393",
        "ok": "393",
        "ko": "-"
    },
    "percentiles2": {
        "total": "403",
        "ok": "403",
        "ko": "-"
    },
    "percentiles3": {
        "total": "411",
        "ok": "411",
        "ko": "-"
    },
    "percentiles4": {
        "total": "413",
        "ok": "413",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-13-5cca6": {
        type: "REQUEST",
        name: "request_13",
path: "request_13",
pathFormatted: "req_request-13-5cca6",
stats: {
    "name": "request_13",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4304",
        "ok": "4304",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7702",
        "ok": "7702",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "6003",
        "ok": "6003",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1699",
        "ok": "1699",
        "ko": "-"
    },
    "percentiles1": {
        "total": "6003",
        "ok": "6003",
        "ko": "-"
    },
    "percentiles2": {
        "total": "6853",
        "ok": "6853",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7532",
        "ok": "7532",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7668",
        "ok": "7668",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-14-a0e30": {
        type: "REQUEST",
        name: "request_14",
path: "request_14",
pathFormatted: "req_request-14-a0e30",
stats: {
    "name": "request_14",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "10176",
        "ok": "10176",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11672",
        "ok": "11672",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10924",
        "ok": "10924",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "748",
        "ok": "748",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10924",
        "ok": "10924",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11298",
        "ok": "11298",
        "ko": "-"
    },
    "percentiles3": {
        "total": "11597",
        "ok": "11597",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11657",
        "ok": "11657",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-15-56eac": {
        type: "REQUEST",
        name: "request_15",
path: "request_15",
pathFormatted: "req_request-15-56eac",
stats: {
    "name": "request_15",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "11164",
        "ok": "11164",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "11466",
        "ok": "11466",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "11315",
        "ok": "11315",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "151",
        "ok": "151",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11315",
        "ok": "11315",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11391",
        "ok": "11391",
        "ko": "-"
    },
    "percentiles3": {
        "total": "11451",
        "ok": "11451",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11463",
        "ok": "11463",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-16-24733": {
        type: "REQUEST",
        name: "request_16",
path: "request_16",
pathFormatted: "req_request-16-24733",
stats: {
    "name": "request_16",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6535",
        "ok": "6535",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7726",
        "ok": "7726",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7131",
        "ok": "7131",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "596",
        "ok": "596",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7131",
        "ok": "7131",
        "ko": "-"
    },
    "percentiles2": {
        "total": "7428",
        "ok": "7428",
        "ko": "-"
    },
    "percentiles3": {
        "total": "7666",
        "ok": "7666",
        "ko": "-"
    },
    "percentiles4": {
        "total": "7714",
        "ok": "7714",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-17-cd6a2": {
        type: "REQUEST",
        name: "request_17",
path: "request_17",
pathFormatted: "req_request-17-cd6a2",
stats: {
    "name": "request_17",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8816",
        "ok": "8816",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9598",
        "ok": "9598",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9207",
        "ok": "9207",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "391",
        "ok": "391",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9207",
        "ok": "9207",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9403",
        "ok": "9403",
        "ko": "-"
    },
    "percentiles3": {
        "total": "9559",
        "ok": "9559",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9590",
        "ok": "9590",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_request-18-f5b64": {
        type: "REQUEST",
        name: "request_18",
path: "request_18",
pathFormatted: "req_request-18-f5b64",
stats: {
    "name": "request_18",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "6872",
        "ok": "6872",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9100",
        "ok": "9100",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7986",
        "ok": "7986",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1114",
        "ok": "1114",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7986",
        "ok": "7986",
        "ko": "-"
    },
    "percentiles2": {
        "total": "8543",
        "ok": "8543",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8989",
        "ok": "8989",
        "ko": "-"
    },
    "percentiles4": {
        "total": "9078",
        "ok": "9078",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    },"req_confirm-checkou-434ff": {
        type: "REQUEST",
        name: "Confirm CHeckout",
path: "Confirm CHeckout",
pathFormatted: "req_confirm-checkou-434ff",
stats: {
    "name": "Confirm CHeckout",
    "numberOfRequests": {
        "total": "2",
        "ok": "2",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "425",
        "ok": "425",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "717",
        "ok": "717",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "571",
        "ok": "571",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "146",
        "ok": "146",
        "ko": "-"
    },
    "percentiles1": {
        "total": "571",
        "ok": "571",
        "ko": "-"
    },
    "percentiles2": {
        "total": "644",
        "ok": "644",
        "ko": "-"
    },
    "percentiles3": {
        "total": "702",
        "ok": "702",
        "ko": "-"
    },
    "percentiles4": {
        "total": "714",
        "ok": "714",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 2,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.067",
        "ok": "0.067",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
