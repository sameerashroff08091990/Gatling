
import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class SauceDemoFinal extends Simulation {

	val httpProtocol = http
		.baseUrl("https://www.saucedemo.com")
		.inferHtmlResources()
		.userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 11_2_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36")

	val headers_0 = Map(
		"Upgrade-Insecure-Requests" -> "1",
		"sec-ch-ua" -> """Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99""",
		"sec-ch-ua-mobile" -> "?0")

	val headers_1 = Map(
		"sec-ch-ua" -> """Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99""",
		"sec-ch-ua-mobile" -> "?0")

	val headers_2 = Map(
		"accept" -> "*/*",
		"accept-encoding" -> "gzip, deflate, br",
		"accept-language" -> "en-US,en;q=0.9",
		"sec-ch-ua" -> """Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99""",
		"sec-ch-ua-mobile" -> "?0",
		"sec-fetch-dest" -> "empty",
		"sec-fetch-mode" -> "cors",
		"sec-fetch-site" -> "same-origin")

	val headers_4 = Map(
		"accept" -> "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
		"accept-encoding" -> "gzip, deflate, br",
		"accept-language" -> "en-US,en;q=0.9",
		"sec-ch-ua" -> """Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99""",
		"sec-ch-ua-mobile" -> "?0",
		"sec-fetch-dest" -> "empty",
		"sec-fetch-mode" -> "no-cors",
		"sec-fetch-site" -> "same-origin")



	val scn = scenario("SauceDemoFinal")
		.exec(http("Launch")
			.get("/")
			.headers(headers_0)
			.resources(http("request_1")
			.get("/static/media/Login_Bot_graphic.20658452.png")
			.headers(headers_1),
            http("Login")
			.get("/manifest.json")
			.headers(headers_2),
            http("request_3")
			.get("/icon/apple-icon-144x144.png")
			.headers(headers_1),
            http("request_4")
			.get("/icon/apple-icon-144x144.png")
			.headers(headers_4)))
		.pause(5)
		.exec(http("request_5")
			.get("/static/media/menu3x.34aee3ab.svg")
			.headers(headers_1)
			.resources(http("request_6")
			.get("/static/media/close@3x.3a2a3ada.svg")
			.headers(headers_1),
            http("request_7")
			.get("/static/media/logo3x.096bf4a7.svg")
			.headers(headers_1),
            http("request_8")
			.get("/static/media/SwagBot_Footer_graphic.2e87acec.png")
			.headers(headers_1),
            http("request_9")
			.get("/static/media/cart3x.d236358a.svg")
			.headers(headers_1),
            http("request_10")
			.get("/static/media/headerBot3x.db38f1aa.svg")
			.headers(headers_1),
            http("request_11")
			.get("/static/media/filter3x.4d6d6e7f.svg")
			.headers(headers_1),
            http("request_12")
			.get("/static/media/arrow3x.3aa2d735.svg")
			.headers(headers_1),
            http("request_13")
			.get("/static/media/red-tatt-1200x1500.e32b4ef9.jpg")
			.headers(headers_1),
            http("request_14")
			.get("/static/media/sauce-backpack-1200x1500.34e7aa42.jpg")
			.headers(headers_1),
            http("request_15")
			.get("/static/media/bike-light-1200x1500.a0c9caae.jpg")
			.headers(headers_1),
            http("request_16")
			.get("/static/media/bolt-shirt-1200x1500.c0dae290.jpg")
			.headers(headers_1),
            http("request_17")
			.get("/static/media/sauce-pullover-1200x1500.439fc934.jpg")
			.headers(headers_1),
            http("request_18")
			.get("/static/media/red-onesie-1200x1500.1b15e1fa.jpg")
			.headers(headers_1)))
		.pause(5)
		.exec(http("Confirm CHeckout")
			.get("/static/media/pony-express.46394a5d.png")
			.headers(headers_1))

	setUp(scn.inject(atOnceUsers(2))).protocols(httpProtocol)
}